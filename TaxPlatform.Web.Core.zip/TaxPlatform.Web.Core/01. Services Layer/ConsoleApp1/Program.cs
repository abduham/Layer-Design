﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using testing;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Class1 a = new Class1();
            a.test("a");
        }
    }
}
