﻿using System;
using System.Collections.Generic;

using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using wb = TaxPlatform.Wrapper.Library;
using TaxPlatform.IDataComponents;
using System.Data.SqlClient;

namespace TaxPlatform.DataComponents
{
    public class DataRead : IDataRead
    {
        public void test(string parm)
        {
            var sqlParameter = new List<wb.DBParameter> {
              new wb.DBParameter("",parm,SqlDbType.VarChar,ParameterDirection.Input),
              };
            wb.Wrapper.ExecuteNonQuery("", sqlParameter, wb.DBName.testdb);

           
        }
    }
}
