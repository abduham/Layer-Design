﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Threading;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class ActiveUsers : IDisposable
	{
		public const int LOG_START = 30000;

		public const int LOG_INTERVAL = 1800000;

		public const int USER_REMOVE_INTERVAL_HRS = 1;

		public const int USER_INACTIVE_INTERVAL_MINS = 10;

		public Timer timer;

		private TimerCallback callback;

		public List<ActiveUser> List
		{
			get;
			set;
		}

		public ActiveUsers()
		{
			List = new List<ActiveUser>();
			callback = Tick;
			timer = new Timer(callback, null, 30000, 1800000);
		}

		public void Tick(object stateInfo)
		{
			try
			{
				List.RemoveAll((ActiveUser a) => a.LastActionTime.AddHours(1.0) < DateTime.Now);
				List<ActiveUser> list = List.FindAll((ActiveUser a) => a.LastActionTime.AddMinutes(10.0) > DateTime.Now);
				string text = "";
				int num = 0;
				foreach (ActiveUser item in list)
				{
					if (num > 0)
					{
						text += ",";
					}
					text += item.UserID;
					num++;
				}
				if (text.Length > 1999)
				{
					text = text.Substring(0, 1999);
				}
				string commandText = "Insert into eet_active_users values(getutcdate()," + list.Count + ",'" + text + "')";
				//SQLWrapper.ExecuteNonQuery(CommandType.Text, commandText);
			}
			catch (Exception ex)
			{
				ErrorLogger.LogAndReportError(ex, "system", "Tick", "PMO.Common.Utility", "ActiveUsers");
			}
		}

		public void Dispose()
		{
			try
			{
				if (timer != null)
				{
					timer.Dispose();
					timer = null;
				}
			}
			catch (Exception ex)
			{
				ErrorLogger.LogAndReportError(ex, "system", "InsertEETActiveUsers");
			}
		}
	}

}
