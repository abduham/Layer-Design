﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class AssemblyConfig
	{
		public static Configuration GetDllCofiguration(Assembly targetAssembly)
		{
			string exeConfigFilename = targetAssembly.CodeBase + ".config";
			ExeConfigurationFileMap exeConfigurationFileMap = new ExeConfigurationFileMap();
			exeConfigurationFileMap.ExeConfigFilename = exeConfigFilename;
			ExeConfigurationFileMap fileMap = exeConfigurationFileMap;
			return ConfigurationManager.OpenMappedExeConfiguration(fileMap, ConfigurationUserLevel.None);
		}
	}
}
