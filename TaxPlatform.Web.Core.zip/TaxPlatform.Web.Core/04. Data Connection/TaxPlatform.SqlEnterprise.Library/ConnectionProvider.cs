﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxPlatform.SqlEnterprise.Library
{
	public static class ConnectionProvider
	{
		private static NameValueCollection _moduleConnection = new NameValueCollection();

		private static string _defaultConnection;

		public static string DefaultConnection
		{
			get
			{
				if (string.IsNullOrWhiteSpace(_defaultConnection) && ConfigurationManager.ConnectionStrings["ConnectionString"] != null)
				{
					_defaultConnection = ConfigurationManager.ConnectionStrings["ConnectionString"].ConnectionString;
				}
				return _defaultConnection;
			}
			set
			{
				_defaultConnection = value;
			}
		}

		

		public static string GetModuleConnection(string module)
		{
			string[] array = null;
			if (!string.IsNullOrEmpty(module))
			{
				array = _moduleConnection.GetValues(module);
			}
			return array[0];
		}

		public static bool SetModuleConnection(string module, string connectionString)
		{
			bool result = true;
			if (!string.IsNullOrEmpty(module) && !string.IsNullOrEmpty(connectionString))
			{
				_moduleConnection.Add(module, connectionString);
			}
			else
			{
				result = false;
			}
			return result;
		}
	}
}
