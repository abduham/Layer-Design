﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class DBObjectPerformanceRecord
	{
		public int SessionID
		{
			get;
			set;
		}

		public string DBObjectName
		{
			get;
			set;
		}

		public double ExecutionTimeInSeconds
		{
			get;
			set;
		}

		public DateTime ExecutedAt
		{
			get;
			set;
		}
	}
}
