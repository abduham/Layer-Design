﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Data;
using System.Threading;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class DBObjectsPerformanceData
	{
		public const int TIMER_DUE_TIME = 300000;

		public const int PERF_RECORD_COUNT_THRESHOLD = 50;

		public static Timer timer;

		private TimerCallback callback;

		public ObservableCollection<DBObjectPerformanceRecord> DBPerformanceRecords
		{
			get;
			set;
		}

		public DBObjectsPerformanceData()
		{
			DBPerformanceRecords = new ObservableCollection<DBObjectPerformanceRecord>();
			callback = Tick;
			DBPerformanceRecords.CollectionChanged += DBPerformanceRecords_CollectionChanged;
		}

		public void Tick(object stateInfo)
		{
			string text = "INSERT INTO DB_OBJECTS_PERFORMANCE_LOG ";
			int num = 0;
			foreach (DBObjectPerformanceRecord dBPerformanceRecord in DBPerformanceRecords)
			{
				if (num > 0)
				{
					text += "UNION ALL ";
				}
				string text2 = text;
				text = text2 + "SELECT " + dBPerformanceRecord.SessionID + ",'" + dBPerformanceRecord.DBObjectName.Replace("dbo.", "") + "'," + dBPerformanceRecord.ExecutionTimeInSeconds + ",'" + dBPerformanceRecord.ExecutedAt.ToString() + "' ";
				num++;
			}
			if (DBPerformanceRecords.Count > 0)
			{
				try
				{
					//SQLWrapper.ExecuteNonQuery(CommandType.Text, text);
				}
				catch (Exception ex)
				{
					ErrorLogger.LogAndReportError(ex, "performance logger", "Tick", "DBPerformanceData", "DBObjectsPerformanceData");
				}
				DBPerformanceRecords.Clear();
				timer.Dispose();
				timer = null;
			}
		}

		private void DBPerformanceRecords_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			try
			{
				if (DBPerformanceRecords.Count > 50)
				{
					Tick(null);
				}
				else if (DBPerformanceRecords.Count > 0)
				{
					if (timer != null)
					{
						timer.Change(300000, -1);
					}
					else
					{
						timer = new Timer(callback, null, 300000, -1);
					}
				}
			}
			catch (Exception ex)
			{
				ErrorLogger.LogAndReportError(ex, "performance logger", "DBPerformanceRecords_CollectionChanged", "DBPerformanceData", "DBObjectsPerformanceData");
			}
		}
	}
}
