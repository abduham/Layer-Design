﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.IO;
using System.Web;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class ErrorLogger
	{
		public const string WebServiceErrorMessageToReport = "Web Service encountered an error while performing current action.";

		public const string ApplicationErrorMessageToDisplay = "Application encountered an error while performing current action.";

		private const string SP_GetErrorById = "dbo.GetErrorById";

		private const string SP_GetRecentErrors = "dbo.GetRecentErrors";

		private static string spInsertErrorLog;

		public static string SPInsertErrorLog
		{
			get
			{
				if (string.IsNullOrWhiteSpace(spInsertErrorLog))
				{
					if (ConfigurationManager.AppSettings["SPInsertErrorLog"] != null)
					{
						spInsertErrorLog = ConfigurationManager.AppSettings["SPInsertErrorLog"];
					}
					else
					{
						spInsertErrorLog = "dbo.Insert_Error_Log";
					}
				}
				return spInsertErrorLog;
			}
			set
			{
				spInsertErrorLog = value;
			}
		}

		public static string LogAndReportError(Exception ex, string userName, string methodName, string moduleName = null, string className = null, string clientMachineID = null, string logType = null, int logSeverity = -1)
		{
			if (ex.Message.Contains("Web Service encountered an error while performing current action."))
			{
				return ex.Message;
			}
			string text = "Application encountered an error while performing current action.";
			string str = "ErrorMessage: " + ex.Message;
			if (ex.StackTrace != null)
			{
				StackTrace stackTrace = new StackTrace(ex, fNeedFileInfo: true);
				StackFrame frame = stackTrace.GetFrame(0);
				str = str + " | File: " + Path.GetFileName(frame.GetFileName());
				str = str + " | Method: " + frame.GetMethod().Name;
				str = str + " | LineNumber: " + frame.GetFileLineNumber();
				if (!string.IsNullOrWhiteSpace(ex.HelpLink))
				{
					str = str + " | Helplink: " + ex.HelpLink;
				}
			}
			if (ex.InnerException != null)
			{
				str = str + " | Inner Exception:" + ex.InnerException.Message;
			}
			str = str + " | Stack Trace:" + ex.StackTrace;
			try
			{
				int num = 0;
				string moduleName2 = moduleName ?? GetCurrentPageName();
				string className2 = className ?? string.Empty;
				string clientMachineID2 = clientMachineID ?? GetClientMachineID();
				string logType2 = logType ?? "App Error";
				int logSeverity2 = ((logSeverity == -1) ? 1 : logSeverity);
				num = InsertErrorLog(moduleName2, className2, methodName, userName, logType2, str, logSeverity2, clientMachineID2, "");
				text = text + "<br />Error Code: " + num;
				return text;
			}
			catch (Exception ex2)
			{
				string text2 = "ErrorLogs\\ErrorLog_" + DateTime.Now.Month + DateTime.Now.Year + ".txt";
				string text3 = HttpContext.Current.Server.MapPath(text2);
				text = text + "<br />Error File: " + text2;
				str = "Exception: " + str;
				str = str + ", Log Exception:" + ex2.Message;
				str = str + ", TimeStamp: " + DateTime.Now.ToString();
				str = str + ", User: " + userName;
				str = str + ", Page: " + GetCurrentPageName();
				str = str + ", Method: " + methodName;
				str += "\r\n";
				if (!Directory.Exists(new FileInfo(text3).DirectoryName))
				{
					Directory.CreateDirectory(new FileInfo(text3).DirectoryName);
				}
				 StreamWriter streamWriter = new StreamWriter(text3, append: true);
				streamWriter.Write(str + "\r\n");
				return text;
			}
		}

		public static string LogServiceError(Exception ex, string interfaceName, string serviceClassName, string methodName)
		{
			string empty = string.Empty;
			string text = "Web Service encountered an error while performing current action.";
			try
			{
				empty = "ErrorMessage: " + ex.Message;
				StackTrace stackTrace = new StackTrace(ex, fNeedFileInfo: true);
				StackFrame frame = stackTrace.GetFrame(0);
				empty = empty + " | File: " + Path.GetFileName(frame.GetFileName());
				empty = empty + " | Method: " + frame.GetMethod().Name;
				empty = empty + " | LineNumber: " + frame.GetFileLineNumber();
				if (!string.IsNullOrWhiteSpace(ex.HelpLink))
				{
					empty = empty + " | Helplink: " + ex.HelpLink;
				}
				if (ex.InnerException != null)
				{
					empty = empty + " | Inner Exception:" + ex.InnerException.Message;
				}
				int num = InsertErrorLog(interfaceName, serviceClassName, methodName, "system", "Service Error", empty, 1, "", "");
				text = text + " <br />Error Code: " + num;
				return text;
			}
			catch (Exception ex2)
			{
				string text2 = "ErrorLogs\\ErrorLog_" + DateTime.Now.Month + DateTime.Now.Year + ".txt";
				string text3 = HttpContext.Current.Server.MapPath(text2);
				text = text + "<br />Error File: " + text2;
				empty = "ErrorMessage: " + ex.Message;
				StackTrace stackTrace2 = new StackTrace(ex, fNeedFileInfo: true);
				StackFrame frame2 = stackTrace2.GetFrame(0);
				empty = empty + " | File: " + Path.GetFileName(frame2.GetFileName());
				empty = empty + " | Method: " + frame2.GetMethod().Name;
				empty = empty + " | LineNumber: " + frame2.GetFileLineNumber();
				if (!string.IsNullOrWhiteSpace(ex.HelpLink))
				{
					empty = empty + " | Helplink: " + ex.HelpLink;
				}
				if (ex.InnerException != null)
				{
					empty = empty + " | Inner Exception:" + ex.InnerException.Message;
				}
				empty = "Exception: " + empty;
				empty = empty + ", Log Exception:" + ex2.Message;
				empty = empty + ", TimeStamp: " + DateTime.Now.ToString();
				empty = empty + ", Interface Name: " + interfaceName;
				empty = empty + ", Class Name: " + serviceClassName;
				empty = empty + ", Method: " + methodName;
				empty += "\r\n";
				if (!Directory.Exists(new FileInfo(text3).DirectoryName))
				{
					Directory.CreateDirectory(new FileInfo(text3).DirectoryName);
				}
				 StreamWriter streamWriter = new StreamWriter(text3, append: true);
				streamWriter.Write(empty + "\r\n");
				return text;
			}
		}

		private static string GetCurrentPageName()
		{
			try
			{
				string absolutePath = HttpContext.Current.Request.Url.AbsolutePath;
				int num = absolutePath.LastIndexOf('/');
				return absolutePath.Substring(num + 1);
			}
			catch (Exception)
			{
				return string.Empty;
			}
		}

		private static string GetClientMachineID()
		{
			try
			{
				return HttpContext.Current.Request.UserHostAddress;
			}
			catch (Exception)
			{
				return string.Empty;
			}
		}

		private static int InsertErrorLog(string moduleName, string className, string methodName, string userName, string logType, string message, int logSeverity, string clientMachineID, string clientDomainName)
		{
			
			return Convert.ToInt32(0);
		}

		public static string GetErrorById(int logId)
		{
			
			return Convert.ToString(0);
		}

		public static DataTable GetRecentErrors(int count)
		{
			DataTable result = null;
			
			return result;
		}
	}
}
