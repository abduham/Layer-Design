﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml;

namespace TaxPlatform.SqlEnterprise.Library
{
	public static class SQLWrapper
	{
		private static string connectionString = ConnectionProvider.DefaultConnection;

		public static float thresholdTime = 0.1f;

		public static int ExecuteNonQuery(CommandType commandType, string commandText, params SqlParameter[] commandParameters)
		{
			return ExecuteNonQuery(connectionString, commandType, commandText, commandParameters);
		}

		public static int ExecuteNonQuery(CommandType commandType, string commandText)
		{
			return ExecuteNonQuery(connectionString, commandType, commandText, (SqlParameter[])null);
		}

		public static int ExecuteNonQuery(string connString, CommandType commandType, string commandText)
		{
			return ExecuteNonQuery(connString, commandType, commandText, (SqlParameter[])null);
		}

		public static int ExecuteNonQuery(SqlTransaction transaction, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
		{
			return SqlHelper.ExecuteNonQuery(transaction, commandType, commandText, commandParameters);
		}

		public static int ExecuteNonQuery(string spName, params SqlParameter[] commandParameters)
		{
			return ExecuteNonQuery(connectionString, CommandType.StoredProcedure, spName, commandParameters);
		}

		public static int ExecuteNonQuery(string connString, string spName, params SqlParameter[] commandParameters)
		{
			return ExecuteNonQuery(connString, CommandType.StoredProcedure, spName, commandParameters);
		}

		public static int ExecuteNonQuery(string connString, CommandType commandType, string commandText, params SqlParameter[] commandParameters)
		{
			//if (HttpContext.Current != null && HttpContext.Current.Session["LogDBObjectsPerformanceData"] != null)
			//{
			//	DBObjectsPerformanceData dBObjectsPerformanceData = null;
			//	if (HttpContext.Current.Session["DBPerformanceDataObj"] == null)
			//	{
			//		dBObjectsPerformanceData = new DBObjectsPerformanceData();
			//		HttpContext.Current.Session["DBPerformanceDataObj"] = dBObjectsPerformanceData;
			//	}
			//	else
			//	{
			//		dBObjectsPerformanceData = HttpContext.Current.Session["DBPerformanceDataObj"] as DBObjectsPerformanceData;
			//	}
			//	DateTime now = DateTime.Now;
			//	int result = SqlHelper.ExecuteNonQuery(connString, commandType, commandText, commandParameters);
			//	TimeSpan timeSpan = DateTime.Now - now;
			//	if (timeSpan.TotalSeconds > (double)thresholdTime)
			//	{
			//		if (HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] == null)
			//		{
			//			string s = DateTime.Now.Year.ToString().Substring(2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
			//			HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] = int.Parse(s);
			//		}
			//		int sessionID = (int)HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"];
			//		DBObjectPerformanceRecord dBObjectPerformanceRecord = new DBObjectPerformanceRecord();
			//		dBObjectPerformanceRecord.SessionID = sessionID;
			//		dBObjectPerformanceRecord.DBObjectName = commandText;
			//		dBObjectPerformanceRecord.ExecutionTimeInSeconds = timeSpan.TotalSeconds;
			//		dBObjectPerformanceRecord.ExecutedAt = DateTime.Now;
			//		DBObjectPerformanceRecord item = dBObjectPerformanceRecord;
			//		dBObjectsPerformanceData.DBPerformanceRecords.Add(item);
			//	}
			//	return result;
			//}
			return SqlHelper.ExecuteNonQuery(connString, commandType, commandText, commandParameters);
		}

		public static DataSet ExecuteDataset(string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteDataset(connectionString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static DataSet ExecuteDataset(string connString, CommandType commandType, string commandText, params SqlParameter[] parameterValues)
		{
			if (HttpContext.Current != null && HttpContext.Current.Session != null && HttpContext.Current.Session["LogDBObjectsPerformanceData"] != null)
			{
				DBObjectsPerformanceData dBObjectsPerformanceData = null;
				if (HttpContext.Current.Session["DBPerformanceDataObj"] == null)
				{
					dBObjectsPerformanceData = new DBObjectsPerformanceData();
					HttpContext.Current.Session["DBPerformanceDataObj"] = dBObjectsPerformanceData;
				}
				else
				{
					dBObjectsPerformanceData = HttpContext.Current.Session["DBPerformanceDataObj"] as DBObjectsPerformanceData;
				}
				DateTime now = DateTime.Now;
				DataSet result = SqlHelper.ExecuteDataset(connString, commandType, commandText, parameterValues);
				TimeSpan timeSpan = DateTime.Now - now;
				if (timeSpan.TotalSeconds > (double)thresholdTime)
				{
					if (HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] == null)
					{
						string s = DateTime.Now.Year.ToString().Substring(2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
						HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] = int.Parse(s);
					}
					int sessionID = (int)HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"];
					DBObjectPerformanceRecord dBObjectPerformanceRecord = new DBObjectPerformanceRecord();
					dBObjectPerformanceRecord.SessionID = sessionID;
					dBObjectPerformanceRecord.DBObjectName = commandText;
					dBObjectPerformanceRecord.ExecutionTimeInSeconds = timeSpan.TotalSeconds;
					dBObjectPerformanceRecord.ExecutedAt = DateTime.Now;
					DBObjectPerformanceRecord item = dBObjectPerformanceRecord;
					dBObjectsPerformanceData.DBPerformanceRecords.Add(item);
				}
				return result;
			}
			return SqlHelper.ExecuteDataset(connString, commandType, commandText, parameterValues);
		}

		public static DataSet ExecuteDataset(CommandType commandType, string commandText)
		{
			return ExecuteDataset(connectionString, commandType, commandText, (SqlParameter[])null);
		}

		public static DataSet ExecuteDataset(string connString, CommandType commandType, string commandText)
		{
			return ExecuteDataset(connString, commandType, commandText, (SqlParameter[])null);
		}

		public static DataSet ExecuteDataset(string spName)
		{
			return ExecuteDataset(connectionString, CommandType.StoredProcedure, spName, (SqlParameter[])null);
		}

		public static DataSet ExecuteDataset(string connString, string spName)
		{
			return ExecuteDataset(connString, CommandType.StoredProcedure, spName, (SqlParameter[])null);
		}

		public static DataSet ExecuteDataset(string connString, string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteDataset(connString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static DataSet ExecuteDataset(CommandType commandType, string commandText, params SqlParameter[] commandParameters)
		{
			return ExecuteDataset(connectionString, commandType, commandText, commandParameters);
		}

		public static object ExecuteScalar(CommandType commandType, string commandText)
		{
			return ExecuteScalar(connectionString, commandType, commandText, (SqlParameter[])null);
		}

		public static object ExecuteScalar(string connString, CommandType commandType, string commandText)
		{
			return SqlHelper.ExecuteScalar(connString, commandType, commandText, (SqlParameter[])null);
		}

		public static object ExecuteScalar(string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteScalar(connectionString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static object ExecuteScalar(string connString, CommandType commandType, string commandText, params SqlParameter[] parameterValues)
		{
			if (HttpContext.Current != null && HttpContext.Current.Session["LogDBObjectsPerformanceData"] != null)
			{
				DBObjectsPerformanceData dBObjectsPerformanceData = null;
				if (HttpContext.Current.Session["DBPerformanceDataObj"] == null)
				{
					dBObjectsPerformanceData = new DBObjectsPerformanceData();
					HttpContext.Current.Session["DBPerformanceDataObj"] = dBObjectsPerformanceData;
				}
				else
				{
					dBObjectsPerformanceData = HttpContext.Current.Session["DBPerformanceDataObj"] as DBObjectsPerformanceData;
				}
				DateTime now = DateTime.Now;
				object result = SqlHelper.ExecuteScalar(connString, commandType, commandText, parameterValues);
				TimeSpan timeSpan = DateTime.Now - now;
				if (timeSpan.TotalSeconds > (double)thresholdTime)
				{
					if (HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] == null)
					{
						string s = DateTime.Now.Year.ToString().Substring(2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
						HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] = int.Parse(s);
					}
					int sessionID = (int)HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"];
					DBObjectPerformanceRecord dBObjectPerformanceRecord = new DBObjectPerformanceRecord();
					dBObjectPerformanceRecord.SessionID = sessionID;
					dBObjectPerformanceRecord.DBObjectName = commandText;
					dBObjectPerformanceRecord.ExecutionTimeInSeconds = timeSpan.TotalSeconds;
					dBObjectPerformanceRecord.ExecutedAt = DateTime.Now;
					DBObjectPerformanceRecord item = dBObjectPerformanceRecord;
					dBObjectsPerformanceData.DBPerformanceRecords.Add(item);
				}
				return result;
			}
			return SqlHelper.ExecuteScalar(connString, commandType, commandText, parameterValues);
		}

		public static object ExecuteScalar(string spName)
		{
			return ExecuteScalar(connectionString, CommandType.StoredProcedure, spName, (SqlParameter[])null);
		}

		public static object ExecuteScalar(string connString, string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteScalar(connString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static SqlDataReader ExecuteReader(string spName)
		{
			return ExecuteReader(connectionString, CommandType.StoredProcedure, spName, (SqlParameter[])null);
		}

		public static SqlDataReader ExecuteReader(string connString, string spName)
		{
			return ExecuteReader(connString, CommandType.StoredProcedure, spName, (SqlParameter[])null);
		}

		public static SqlDataReader ExecuteReader(string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteReader(connectionString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static SqlDataReader ExecuteReader(string connString, string spName, params SqlParameter[] parameterValues)
		{
			return ExecuteReader(connString, CommandType.StoredProcedure, spName, parameterValues);
		}

		public static SqlDataReader ExecuteReader(string connString, CommandType commandType, string commandText, params SqlParameter[] parameterValues)
		{
			if (HttpContext.Current != null && HttpContext.Current.Session["LogDBObjectsPerformanceData"] != null)
			{
				DBObjectsPerformanceData dBObjectsPerformanceData = null;
				if (HttpContext.Current.Session["DBPerformanceDataObj"] == null)
				{
					dBObjectsPerformanceData = new DBObjectsPerformanceData();
					HttpContext.Current.Session["DBPerformanceDataObj"] = dBObjectsPerformanceData;
				}
				else
				{
					dBObjectsPerformanceData = HttpContext.Current.Session["DBPerformanceDataObj"] as DBObjectsPerformanceData;
				}
				DateTime now = DateTime.Now;
				SqlDataReader result = SqlHelper.ExecuteReader(connString, commandType, commandText, parameterValues);
				TimeSpan timeSpan = DateTime.Now - now;
				if (timeSpan.TotalSeconds > (double)thresholdTime)
				{
					if (HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] == null)
					{
						string s = DateTime.Now.Year.ToString().Substring(2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
						HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] = int.Parse(s);
					}
					int sessionID = (int)HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"];
					DBObjectPerformanceRecord dBObjectPerformanceRecord = new DBObjectPerformanceRecord();
					dBObjectPerformanceRecord.SessionID = sessionID;
					dBObjectPerformanceRecord.DBObjectName = commandText;
					dBObjectPerformanceRecord.ExecutionTimeInSeconds = timeSpan.TotalSeconds;
					dBObjectPerformanceRecord.ExecutedAt = DateTime.Now;
					DBObjectPerformanceRecord item = dBObjectPerformanceRecord;
					dBObjectsPerformanceData.DBPerformanceRecords.Add(item);
				}
				return result;
			}
			return SqlHelper.ExecuteReader(connString, commandType, commandText, parameterValues);
		}

		public static object ExecuteScalarForXML(string connString, string spName, params object[] parameterValues)
		{
			StringBuilder stringBuilder = new StringBuilder();
			SqlConnection sqlConnection = null;
			XmlReader xmlReader = null;
			DateTime now;
			DateTime now2;
			try
			{
				now = DateTime.Now;
				sqlConnection = new SqlConnection(connString);
				sqlConnection.Open();
				xmlReader = SqlHelper.ExecuteXmlReader(sqlConnection, spName, parameterValues);
				xmlReader.Read();
				while (xmlReader.ReadState != ReadState.EndOfFile)
				{
					stringBuilder.Append(xmlReader.ReadOuterXml());
				}
				now2 = DateTime.Now;
			}
			catch (Exception ex)
			{
				throw ex;
			}
			finally
			{
				if (xmlReader.ReadState != ReadState.Closed)
				{
					xmlReader.Close();
				}
				if (sqlConnection.State != 0)
				{
					sqlConnection.Close();
				}
			}
			if (HttpContext.Current != null && HttpContext.Current.Session["LogDBObjectsPerformanceData"] != null)
			{
				DBObjectsPerformanceData dBObjectsPerformanceData = null;
				if (HttpContext.Current.Session["DBPerformanceDataObj"] == null)
				{
					dBObjectsPerformanceData = new DBObjectsPerformanceData();
					HttpContext.Current.Session["DBPerformanceDataObj"] = dBObjectsPerformanceData;
				}
				else
				{
					dBObjectsPerformanceData = HttpContext.Current.Session["DBPerformanceDataObj"] as DBObjectsPerformanceData;
				}
				TimeSpan timeSpan = now2 - now;
				if (timeSpan.TotalSeconds > (double)thresholdTime)
				{
					if (HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] == null)
					{
						string s = DateTime.Now.Year.ToString().Substring(2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
						HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"] = int.Parse(s);
					}
					int sessionID = (int)HttpContext.Current.Session["LogDBObjectsPerformanceSessionID"];
					DBObjectPerformanceRecord dBObjectPerformanceRecord = new DBObjectPerformanceRecord();
					dBObjectPerformanceRecord.SessionID = sessionID;
					dBObjectPerformanceRecord.DBObjectName = spName;
					dBObjectPerformanceRecord.ExecutionTimeInSeconds = timeSpan.TotalSeconds;
					dBObjectPerformanceRecord.ExecutedAt = DateTime.Now;
					DBObjectPerformanceRecord item = dBObjectPerformanceRecord;
					dBObjectsPerformanceData.DBPerformanceRecords.Add(item);
				}
			}
			return stringBuilder.ToString();
		}

		public static object ExecuteScalarForXML(string spName, params object[] parameterValues)
		{
			return ExecuteScalarForXML(connectionString, spName, parameterValues);
		}

		public static SqlParameter CreateSQLParameter(string parameterName, SqlDbType sqlDBType, int size, ParameterDirection direction, object value)
		{
			SqlParameter sqlParameter = new SqlParameter(parameterName, sqlDBType, size);
			sqlParameter.Direction = direction;
			sqlParameter.Value = value;
			return sqlParameter;
		}

		public static SqlParameter CreateSQLParameter(string parameterName, SqlDbType sqlDBType, ParameterDirection direction, object value)
		{
			SqlParameter sqlParameter = new SqlParameter(parameterName, sqlDBType);
			sqlParameter.Direction = direction;
			sqlParameter.Value = value;
			return sqlParameter;
		}
	}
}
