﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class TrackActiveUsers
	{
		public static void Track(string userID)
		{
			try
			{
				if (HttpContext.Current.Application["TrackActiveUsers"] != null)
				{
					if (HttpContext.Current.Application["ActiveUsers"] == null)
					{
						HttpContext.Current.Application["ActiveUsers"] = new ActiveUsers();
					}
					ActiveUsers activeUsers = HttpContext.Current.Application["ActiveUsers"] as ActiveUsers;
					if (activeUsers.List.Exists((ActiveUser a) => a.UserID == userID))
					{
						activeUsers.List.Find((ActiveUser a) => a.UserID == userID).LastActionTime = DateTime.Now;
						return;
					}
					ActiveUser activeUser = new ActiveUser();
					activeUser.UserID = userID;
					activeUser.LastActionTime = DateTime.Now;
					ActiveUser item = activeUser;
					activeUsers.List.Add(item);
				}
				else if (HttpContext.Current.Application["ActiveUsers"] != null)
				{
					ActiveUsers activeUsers2 = HttpContext.Current.Application["ActiveUsers"] as ActiveUsers;
					activeUsers2.Dispose();
					HttpContext.Current.Application["ActiveUsers"] = null;
				}
			}
			catch (Exception ex)
			{
				string userName = userID.ToString();
				ErrorLogger.LogAndReportError(ex, userName, "Track", "PMO.Utility.Common", "TrackActiveUsers");
			}
		}
	}
}
