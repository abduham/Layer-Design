﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TaxPlatform.SqlEnterprise.Library
{
	public class WebObjectPerformanceRecord
	{
		public int SessionID
		{
			get;
			set;
		}

		public string ObjectName
		{
			get;
			set;
		}

		public string RequestType
		{
			get;
			set;
		}

		public string RequestMethod
		{
			get;
			set;
		}

		public double SizeInKB
		{
			get;
			set;
		}

		public double ProcessTimeInSeconds
		{
			get;
			set;
		}

		public DateTime ProcessedAt
		{
			get;
			set;
		}
	}

}
