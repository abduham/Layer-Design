﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Collections.Specialized;
using System.Data;


namespace TaxPlatform.SqlEnterprise.Library
{
	public class WebObjectsPerformanceData
	{
		public const int TIMER_DUE_TIME = 300000;

		public const int PERF_RECORD_COUNT_THRESHOLD = 50;

		public static Timer timer;

		private TimerCallback callback;

		public ObservableCollection<WebObjectPerformanceRecord> WebPerformanceRecords
		{
			get;
			set;
		}

		public WebObjectsPerformanceData()
		{
			WebPerformanceRecords = new ObservableCollection<WebObjectPerformanceRecord>();
			callback = Tick;
			WebPerformanceRecords.CollectionChanged += WebPerformanceRecords_CollectionChanged;
		}

		public void Tick(object stateInfo)
		{
			string text = "INSERT INTO WEB_OBJECTS_PERFORMANCE_LOG ";
			int num = 0;
			foreach (WebObjectPerformanceRecord webPerformanceRecord in WebPerformanceRecords)
			{
				if (num > 0)
				{
					text += "UNION ALL ";
				}
				object obj = text;
				text = string.Concat(obj, "SELECT ", webPerformanceRecord.SessionID.ToString(), ",'", webPerformanceRecord.ObjectName, "','", webPerformanceRecord.RequestType.ToString(), "','", webPerformanceRecord.RequestMethod, "',", webPerformanceRecord.SizeInKB, ",", webPerformanceRecord.ProcessTimeInSeconds, ",'", webPerformanceRecord.ProcessedAt.ToString(), "' ");
				num++;
			}
			if (WebPerformanceRecords.Count > 0)
			{
				try
				{
					//SQLWrapper.ExecuteNonQuery(CommandType.Text, text);
				}
				catch (Exception ex)
				{
					ErrorLogger.LogAndReportError(ex, "performance logger", "Tick", "WebPerformanceData", "WebObjectsPerformanceData");
				}
				WebPerformanceRecords.Clear();
				timer.Dispose();
				timer = null;
			}
		}

		private void WebPerformanceRecords_CollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
		{
			try
			{
				if (WebPerformanceRecords.Count > 50)
				{
					Tick(null);
				}
				else if (WebPerformanceRecords.Count > 0)
				{
					if (timer != null)
					{
						timer.Change(300000, -1);
					}
					else
					{
						timer = new Timer(callback, null, 300000, -1);
					}
				}
			}
			catch (Exception ex)
			{
				ErrorLogger.LogAndReportError(ex, "performance logger", "WebPerformanceRecords_CollectionChanged", "WebPerformanceData", "WebObjectsPerformanceData");
			}
		}
	}
}
