﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxPlatform.SqlEnterprise.Library;

namespace TaxPlatform.Wrapper.Library
{
    public static class Wrapper
    {
        

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(CommandType commandType, string commandText, DBName database)
        {
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), commandType, commandText);
        }



        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static int ExecuteNonQuery(string spName, DBName database, params SqlParameter[] commandParameters)
        {
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), spName, commandParameters);
        }


        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string spName, IList<DBParameter> commandParameters, DBName database)
        {
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), spName, commandParameters.ToList().GetSqlParameterArray());
        }


        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(string spName, IList<SizedDBParameter> commandParameters, DBName database)
        {
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), spName, commandParameters.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static int ExecuteNonQuery(CommandType commandType, string commandText, DBName database, params SqlParameter[] commandParameters)
        {
            if (commandParameters == null)
                throw new ArgumentNullException("commandParameters");
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), commandType, commandText, commandParameters);
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(CommandType commandType, string commandText, IList<DBParameter> commandParameters, DBName database)
        {
            if (commandParameters == null)
                throw new ArgumentNullException("commandParameters");
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), commandType, commandText, commandParameters.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the non query.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="commandParameters">The command parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static int ExecuteNonQuery(CommandType commandType, string commandText, IList<SizedDBParameter> commandParameters, DBName database)
        {
            if (commandParameters == null)
                throw new ArgumentNullException("commandParameters");
            return SQLWrapper.ExecuteNonQuery(GetConnectionString(database), commandType, commandText, commandParameters.ToList().GetSqlParameterArray());
        }


        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(CommandType commandType, string commandText, DBName database)
        {
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), commandType, commandText);
        }




        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(string spName, DBName database)
        {
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), spName);
        }




        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static DataSet ExecuteDataSet(string spName, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), spName, parameterValues);
        }


        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(string spName, IList<DBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), spName, parameterValues.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(string spName, IList<SizedDBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), spName, parameterValues.ToList().GetSqlParameterArray());
        }




        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static DataSet ExecuteDataSet(CommandType commandType, string commandText, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), commandType, commandText, parameterValues);
        }



        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(CommandType commandType, string commandText, IList<DBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), commandType, commandText, parameterValues.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the dataset.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static DataSet ExecuteDataSet(CommandType commandType, string commandText, IList<SizedDBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteDataset(GetConnectionString(database), commandType, commandText, parameterValues.ToList().GetSqlParameterArray());
        }


        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <returns></returns>
        public static object ExecuteScalar(CommandType commandType, string commandText, DBName database)
        {
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), commandType, commandText);
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="database">Name of the db.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static object ExecuteScalar(CommandType commandType, string commandText, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), commandType, commandText, parameterValues);
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static object ExecuteScalar(CommandType commandType, string commandText, IList<DBParameter> parameters, DBName database)
        {
            if (parameters == null)
                throw new ArgumentNullException("parameters");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), commandType, commandText, parameters.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameters">The parameters.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static object ExecuteScalar(CommandType commandType, string commandText, IList<SizedDBParameter> parameters, DBName database)
        {
            if (parameters == null)
                throw new ArgumentNullException("parameters");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), commandType, commandText, parameters.ToList().GetSqlParameterArray());
        }




        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static object ExecuteScalar(string spName, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), spName, parameterValues);
        }



        public static object ExecuteScalar(string spName, IList<DBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), spName, parameterValues.ToList().GetSqlParameterArray());
        }

        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static object ExecuteScalar(string spName, IList<SizedDBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteScalar(GetConnectionString(database), spName, parameterValues.ToList().GetSqlParameterArray());
        }
        /// <summary>
        /// Executes the scalar.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <returns></returns>

        public static object ExecuteScalar(string spName)
        {
            return SQLWrapper.ExecuteScalar(spName); //TODO: Need to ask Sudheer
        }



        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <returns></returns>
        public static SqlDataReader ExecuteReader(string spName, DBName database)
        {
            return SQLWrapper.ExecuteReader(GetConnectionString(database), spName);
        }

       

        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static SqlDataReader ExecuteReader(string spName, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteReader(GetConnectionString(database), spName, parameterValues);
        }


        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static SqlDataReader ExecuteReader(string spName, IList<DBParameter> parameterValues, DBName database)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteReader(GetConnectionString(database), CommandType.StoredProcedure, spName, parameterValues.ToList().GetSqlParameterArray());
        }


        /// <summary>
        /// Executes the reader.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="commandType">Type of the command.</param>
        /// <param name="commandText">The command text.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>

        public static SqlDataReader ExecuteReader(CommandType commandType, string commandText, DBName database, params SqlParameter[] parameterValues)
        {
            if (parameterValues == null)
                throw new ArgumentNullException("parameterValues");
            return SQLWrapper.ExecuteReader(GetConnectionString(database), commandType, commandText, parameterValues);
        }


        /// <summary>
        /// Executes the scalar for XML.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete, Use other Overloaded methods")]
        public static object ExecuteScalarForxml(string spName, DBName database, params object[] parameterValues)
        {
            return SQLWrapper.ExecuteScalarForXML(GetConnectionString(database), spName, parameterValues);
        }

        /// <summary>
        /// Executes the scalar for xml.
        /// </summary>
        /// <param name="spName">Name of the sp.</param>
        /// <param name="parameterValues">The parameter values.</param>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        public static object ExecuteScalarForxml(string spName, IList<DBParameter> parameterValues, DBName database)
        {
            return SQLWrapper.ExecuteScalarForXML(GetConnectionString(database), spName, parameterValues.ToList().GetSqlParameterArray());
        }

       

        /// <summary>
        /// Creates the SQL parameter.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="sqlDBType">Type of the SQL DB.</param>
        /// <param name="size">The size.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete")]
        public static SqlParameter CreateSQLParameter(string parameterName, SqlDbType sqlDBType, int size, ParameterDirection direction, object value)
        {
            return SQLWrapper.CreateSQLParameter(parameterName, sqlDBType, size, direction, value);
        }

        /// <summary>
        /// Creates the SQL parameter.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="sqlDBType">Type of the SQL DB.</param>
        /// <param name="direction">The direction.</param>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        [Obsolete("This method is obsolete")]
        public static SqlParameter CreateSQLParameter(string parameterName, SqlDbType sqlDBType, ParameterDirection direction, object value)
        {
            return SQLWrapper.CreateSQLParameter(parameterName, sqlDBType, direction, value);
        }


        /// <summary>
        /// Gets the connection string.
        /// </summary>
        /// <param name="database">Name of the db.</param>
        /// <returns></returns>
        private static string GetConnectionString(DBName database)
        {
            var connectionStringName = "ConnectionString";
           
            return "Server=.;User ID=sa;Password=sa;Trusted_Connection=true;Initial Catalog=WeatherDB";
                
                //ConfigurationManager.ConnectionStrings[database.ToString() + connectionStringName].ConnectionString;
        }

        
    }

  
    public class DBParameter
    {
        public string ParameterName
        {
            get;
            set;
        }
        public SqlDbType DBType
        {
            get;
            set;
        }
        public ParameterDirection ParameterDirection
        {
            get;
            set;
        }
        public object ParameterValue
        {
            get;
            set;
        }
        public int InputParameterId
        {
            get;
            set;
        }
        public int ProjectId
        {
            get;
            set;
        }





        /// <summary>
        /// Gets the SQL parameter from object of the <see cref="DBParameter"/> class.
        /// </summary>
        /// <returns></returns>
        public SqlParameter GetSqlParameter()
        {
            return SQLWrapper.CreateSQLParameter(ParameterName, DBType, ParameterDirection, ParameterValue);
        }
        /// <summary>
        /// Initializes a new instance of the <see cref="DBParameter"/> class.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="sqlDataType">Type of the db.</param>
        /// <param name="parameterDirection">The parameter direction.</param>
        /// <param name="parameterValue">The parameter value.</param>
        public DBParameter(string parameterName, object parameterValue, SqlDbType sqlDataType, ParameterDirection parameterDirection)
        {
            ParameterName = parameterName.StartsWith("@", StringComparison.Ordinal) ? parameterName : "@" + parameterName;
            ParameterValue = parameterValue;
            DBType = sqlDataType;
            ParameterDirection = parameterDirection;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="DBParameter"/> class.
        /// </summary>
        public DBParameter()
        {
            ParameterDirection = ParameterDirection.Input;
            DBType = SqlDbType.VarChar;
        }

        public DBParameter(int inputRequestId, int projectId)
        {
            InputParameterId = inputRequestId;
            projectId = ProjectId;
        }
    }

    public class SizedDBParameter : DBParameter
    {
        public int Size
        {
            get;
            set;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SizedDBParameter"/> class.
        /// </summary>
        /// <param name="parameterName">Name of the parameter.</param>
        /// <param name="sqlDataType">Type of the db.</param>
        /// <param name="parameterDirection">The parameter direction.</param>
        /// <param name="parameterValue">The parameter value.</param>
        /// <param name="size">The size.</param>
        public SizedDBParameter(string parameterName, object parameterValue, int size, SqlDbType sqlDataType, ParameterDirection parameterDirection)
            : base(parameterName, parameterValue, sqlDataType, parameterDirection)
        {
            Size = size;
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="SizedDBParameter"/> class.
        /// </summary>
        public SizedDBParameter()
        {
            ParameterDirection = ParameterDirection.Input;
            DBType = SqlDbType.VarChar;
        }

        /// <summary>
        /// Gets the SQL parameter from object of the <see cref="DBParameter"/> class.
        /// </summary>
        /// <returns></returns>
        public new SqlParameter GetSqlParameter()
        {
            return SQLWrapper.CreateSQLParameter(ParameterName, DBType, Size, ParameterDirection, ParameterValue);
        }

    }

    public static class DBExtensions
    {
        /// <summary>
        /// Gets the SQL parameter array.
        /// </summary>
        /// <param name="parametes">The parametes.</param>
        /// <returns></returns>
        public static SqlParameter[] GetSqlParameterArray(this IList<DBParameter> parametes)
        {
            var sqlParameters = new List<SqlParameter>();
            parametes.ToList().ForEach(p => sqlParameters.Add(p.GetSqlParameter()));
            return sqlParameters.ToArray();
        }

        public static IList<DBParameter> GetDBParamters(this SqlParameter[] sqlParameters)
        {
            return sqlParameters.Select(sqlParameter => new DBParameter(sqlParameter.ParameterName, sqlParameter.Value, sqlParameter.SqlDbType, sqlParameter.Direction)).ToList();
        }

        /// <summary>
        /// Gets the SQL parameter array.
        /// </summary>
        /// <param name="parametes">The parametes.</param>
        /// <returns></returns>
        public static SqlParameter[] GetSqlParameterArray(this IList<SizedDBParameter> parametes)
        {
            var sqlParameters = new List<SqlParameter>();
            parametes.ToList().ForEach(p => sqlParameters.Add(p.GetSqlParameter()));
            return sqlParameters.ToArray();
        }

        /// <summary>
        /// Gets the DmsDBParameter List.
        /// </summary>
        /// <param name="parameterCollection">The parameter collection.</param>
        /// <returns></returns>
        public static IList<DBParameter> GetDBParameters(this SqlParameterCollection parameterCollection)
        {
            return (from SqlParameter sqlParameter in parameterCollection
                    select new DBParameter(sqlParameter.ParameterName, sqlParameter.Value, sqlParameter.SqlDbType, sqlParameter.Direction)).ToList();
        }
        
    }
}
