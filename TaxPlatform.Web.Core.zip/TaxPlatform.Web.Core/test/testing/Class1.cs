﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TaxPlatform.Wrapper.Library;

namespace testing
{
    public class Class1
    {
        public void test(string parm)
        {
            var sqlParameter = new List<DBParameter> {
            new DBParameter("",parm,SqlDbType.VarChar,ParameterDirection.Input),
            };
            Wrapper.ExecuteNonQuery("",sqlParameter,DBName.testdb);
        }
    }
}
